clear
clc

%% Setup path and bicycle parameters
cd 'C:\Users\FoR\Documents\Lets play' % Change this to the directory your "Lets Play" Folder is located.

addpath('8km Plant','12km Plant','15km Plant')
DynamicModelParameters
disp('>> Bicycle Parameters loaded')

disp('>> Dynamic model loaded')

%% Start project
disp('1: 8km/h Model, 2: 12km/h Model, 3: 15km/h Model')

model = input('Choose model: ');

switch model
   case 1   % Bicycle model desigend to run at 8km/h
      cd '8km Plant'
      Nonlinear_Torque_8km
      Controller_8km
      disp('>> 8km/h Plant: Ready')
   case 2   % Bicycle model desigend to run at 12km/h
      cd '12km Plant'
      Nonlinear_Torque_12km
      Controller_12km
      disp('>> 12km/h Plant: Ready')
   case 3   % Bicycle model desigend to run at 15km/h
      cd '15km Plant'
      Nonlinear_Torque_15km
      Controller_15km
      disp('>> 15km/h Plant: Ready')
   otherwise
      disp('It is not that hard to choose between 1-3... idiot.');
end
